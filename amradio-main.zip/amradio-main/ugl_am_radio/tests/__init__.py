"""
UGL AM Radio Control System - Test Suite
"""
